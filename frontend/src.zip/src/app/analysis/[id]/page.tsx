"use client";

import { useEffect, useState, useCallback, Suspense } from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Analysis, getAnalysis } from "@/lib/api";
import AnalysisDetail from "@/components/AnalysisDetail";
import AppHeader, { BackLink } from "@/components/Shell";
import { STATUS_CONFIG } from "@/components/AnalysisList";

function Spinner() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-cyan-300" />
    </div>
  );
}

function AnalysisPageInner() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAnalysis = useCallback(async () => {
    try {
      const data = await getAnalysis(id);
      setAnalysis(data);
      setError(null);
    } catch {
      setError("Analysis not found");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchAnalysis();
  }, [fetchAnalysis]);

  // Auto-poll while processing
  useEffect(() => {
    if (!analysis) return;
    if (analysis.status !== "pending" && analysis.status !== "processing") return;

    const interval = setInterval(fetchAnalysis, 3000);
    return () => clearInterval(interval);
  }, [analysis, fetchAnalysis]);

  if (loading) return <Spinner />;

  if (error || !analysis) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4">
        <p className="text-lg text-rose-400">{error || "Something went wrong"}</p>
        <button onClick={() => router.push("/")} className="btn">
          <ArrowLeft className="h-4 w-4" /> Back to dashboard
        </button>
      </div>
    );
  }

  const cfg = STATUS_CONFIG[analysis.status];

  return (
    <main className="min-h-screen">
      <AppHeader
        active="match"
        center={
          <div className="flex min-w-0 items-center gap-3 rounded-xl border border-[var(--line)] bg-white/[0.03] px-4 py-1.5">
            <span className="chip" style={{ color: cfg.color, background: `${cfg.color}18`, borderColor: `${cfg.color}40` }}>
              {analysis.status === "processing" && <span className="pulse-dot" />}
              {cfg.label.toUpperCase()}
            </span>
            <span className="truncate text-sm font-semibold text-slate-100">{analysis.filename}</span>
            <span className="num hidden text-[11px] text-slate-500 xl:inline">#{analysis.id}</span>
          </div>
        }
      />

      <div className="mx-auto max-w-[1680px] px-4 py-5 sm:px-6">
        <div className="mb-4 flex items-center gap-3">
          <BackLink />
          <p className="num truncate text-[11px] text-slate-500">
            ID {analysis.id} · Created {new Date(analysis.created_at).toLocaleString()}
          </p>
        </div>
        <AnalysisDetail analysis={analysis} />
      </div>
    </main>
  );
}

export default function AnalysisPage() {
  return (
    <Suspense fallback={<Spinner />}>
      <AnalysisPageInner />
    </Suspense>
  );
}
