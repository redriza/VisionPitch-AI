"use client";

import { Crosshair, Route, Shirt, BarChart3, Check, Loader2, Trophy, Braces, BellRing } from "lucide-react";
import type { Analysis, PlayerStat } from "@/lib/api";
import { Panel, StatRow } from "./Panel";
import { PossessionRing, deriveEvents, fmtTime, teamColorFor, teamKeys } from "./AnalyticsDashboard";

const STAGES = [
  { icon: Crosshair, title: "Detection", sub: "Players, ball & referees" },
  { icon: Route, title: "Tracking", sub: "Persistent IDs & trails" },
  { icon: Shirt, title: "Team classification", sub: "Kit colour clustering" },
  { icon: BarChart3, title: "Match analytics", sub: "Speed, distance, possession" },
];

/** Left column: pipeline layers + teams + top performer */
export function LeftRail({ analysis }: { analysis: Analysis }) {
  const a = analysis.analytics;
  const done = analysis.status === "completed";
  const failed = analysis.status === "failed";
  // approximate active stage from overall progress (4 equal quarters)
  const activeIdx = done ? 4 : Math.min(3, Math.floor(analysis.progress / 25));
  const keys = a ? teamKeys(a) : [];
  const top = a ? [...a.player_stats].sort((x, y) => y.max_speed - x.max_speed)[0] : undefined;
  const maxOf = (f: (p: PlayerStat) => number) => (a ? Math.max(1, ...a.player_stats.map(f)) : 1);

  return (
    <>
      <Panel title="Solution layers" bodyClassName="!px-2 !pb-2">
        <ul className="space-y-1">
          {STAGES.map((s, i) => {
            const state = done || i < activeIdx ? "done" : i === activeIdx && !failed ? "active" : failed && i === activeIdx ? "failed" : "todo";
            return (
              <li
                key={s.title}
                className={`flex items-center gap-3 rounded-xl px-2.5 py-2 ${state === "active" ? "bg-cyan-400/[0.07] ring-1 ring-cyan-400/25" : ""}`}
              >
                <span
                  className="layer-badge shrink-0"
                  style={
                    state === "done"
                      ? { color: "#34d399", borderColor: "rgba(52,211,153,.55)", background: "rgba(52,211,153,.08)", boxShadow: "0 0 14px -2px rgba(52,211,153,.5)" }
                      : state === "failed"
                      ? { color: "#f43f5e", borderColor: "rgba(244,63,94,.55)", background: "rgba(244,63,94,.08)" }
                      : state === "todo"
                      ? { color: "#64748b", borderColor: "rgba(100,116,139,.4)", background: "transparent", boxShadow: "none" }
                      : undefined
                  }
                >
                  {state === "done" ? <Check className="h-3 w-3" /> : state === "active" ? <Loader2 className="h-3 w-3 animate-spin" /> : i + 1}
                </span>
                <div className="min-w-0">
                  <p className={`text-[13px] font-medium ${state === "todo" ? "text-slate-500" : "text-slate-100"}`}>{s.title}</p>
                  <p className="truncate text-[11px] text-slate-500">{s.sub}</p>
                </div>
                <s.icon className="ml-auto h-4 w-4 shrink-0 text-slate-600" />
              </li>
            );
          })}
        </ul>
      </Panel>

      {a && (
        <Panel title="Teams" icon={Shirt}>
          <div className="space-y-3">
            {keys.map((k, i) => {
              const num = k.replace("team_", "");
              const color = teamColorFor(keys, num);
              const roster = a.player_stats.filter((p) => String(p.team) === num);
              const avg = roster.length ? roster.reduce((s, p) => s + p.avg_speed, 0) / roster.length : 0;
              return (
                <div key={k}>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2 text-sm font-medium text-slate-100">
                      <span className="h-3 w-3 rounded-sm" style={{ background: color, boxShadow: `0 0 10px ${color}` }} />
                      Team {num}
                    </span>
                    <span className="num text-sm font-semibold" style={{ color }}>{a.team_possession[k].percentage}%</span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/5">
                    <div className="h-full rounded-full" style={{ width: `${a.team_possession[k].percentage}%`, background: color, boxShadow: `0 0 10px ${color}88` }} />
                  </div>
                  <p className="mt-1.5 text-[11px] text-slate-500">
                    <span className="num text-slate-300">{roster.length}</span> players · avg <span className="num text-slate-300">{avg.toFixed(1)}</span> km/h
                  </p>
                  {i < keys.length - 1 && <div className="mt-3 h-px bg-white/[0.05]" />}
                </div>
              );
            })}
          </div>
        </Panel>
      )}

      {a && top && (
        <Panel title="Top performer" icon={Trophy} right={<span className="chip border-emerald-400/30 bg-emerald-400/10 text-emerald-300">Fastest</span>}>
          <div className="mb-2 flex items-center gap-3">
            <span
              className="num grid h-11 w-11 place-items-center rounded-xl text-base font-bold text-white"
              style={{ background: `linear-gradient(135deg, ${top.team_color}, ${top.team_color}88)`, boxShadow: `0 0 20px -4px ${top.team_color}` }}
            >
              {top.player_id}
            </span>
            <div className="flex-1">
              <p className="text-sm font-semibold text-slate-100">Player #{top.player_id}</p>
              <p className="text-[11px] text-slate-500">Team {top.team}</p>
            </div>
            <span className="num rounded-lg border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-1 text-lg font-semibold text-emerald-300">
              {top.max_speed.toFixed(1)}
            </span>
          </div>
          <StatRow label="Peak velocity" value={`${top.max_speed.toFixed(1)} km/h`} pct={(top.max_speed / maxOf((p) => p.max_speed)) * 100} color="#34d399" />
          <StatRow label="Average speed" value={`${top.avg_speed.toFixed(1)} km/h`} pct={(top.avg_speed / maxOf((p) => p.avg_speed)) * 100} color="#22d3ee" />
          <StatRow label="Distance covered" value={`${top.total_distance.toFixed(1)} m`} pct={(top.total_distance / maxOf((p) => p.total_distance)) * 100} color="#a78bfa" />
          <StatRow label="Ball possession" value={`${top.ball_possession_pct.toFixed(1)}%`} pct={top.ball_possession_pct} color="#facc15" />
        </Panel>
      )}
    </>
  );
}

// ── tiny JSON viewer (no innerHTML) ─────────────────────────────────────
function J({ v, d = 0 }: { v: unknown; d?: number }): React.ReactElement {
  const pad = { paddingLeft: 12 };
  if (v === null) return <span className="text-slate-500">null</span>;
  if (typeof v === "string") return <span className="text-emerald-300">&quot;{v}&quot;</span>;
  if (typeof v === "number") return <span className="text-amber-300">{v}</span>;
  if (typeof v === "boolean") return <span className="text-violet-300">{String(v)}</span>;
  if (Array.isArray(v)) {
    return (
      <>
        [
        {v.map((x, i) => (
          <div key={i} style={pad}>
            <J v={x} d={d + 1} />
            {i < v.length - 1 && ","}
          </div>
        ))}
        ]
      </>
    );
  }
  const entries = Object.entries(v as Record<string, unknown>);
  return (
    <>
      {"{"}
      {entries.map(([k, x], i) => (
        <div key={k} style={pad}>
          <span className="text-sky-300">&quot;{k}&quot;</span>: <J v={x} d={d + 1} />
          {i < entries.length - 1 && ","}
        </div>
      ))}
      {"}"}
    </>
  );
}

/** Right column: data feed, events, team metrics */
export function RightRail({ analysis }: { analysis: Analysis }) {
  const a = analysis.analytics;
  if (!a) {
    return (
      <Panel title="Live data feed" icon={Braces}>
        <p className="py-6 text-center text-xs text-slate-500">Data appears when analysis completes</p>
      </Panel>
    );
  }
  const keys = teamKeys(a);
  const top = [...a.player_stats].sort((x, y) => y.max_speed - x.max_speed)[0];
  const feed = {
    analysis_id: analysis.id,
    video: {
      fps: a.video_metadata.fps,
      frames: a.video_metadata.total_frames,
      duration_s: +a.video_metadata.duration_seconds.toFixed(2),
      resolution: `${a.video_metadata.resolution.width}x${a.video_metadata.resolution.height}`,
    },
    summary: a.summary,
    ...(top && {
      fastest_player: { id: top.player_id, team: top.team, max_speed_kmh: +top.max_speed.toFixed(1) },
    }),
  };
  const events = deriveEvents(a);

  const teamAgg = keys.map((k) => {
    const num = k.replace("team_", "");
    const roster = a.player_stats.filter((p) => String(p.team) === num);
    return {
      num,
      color: teamColorFor(keys, num),
      dist: roster.reduce((s, p) => s + p.total_distance, 0),
      top: roster.length ? Math.max(...roster.map((p) => p.max_speed)) : 0,
      ball: roster.reduce((s, p) => s + p.frames_with_ball, 0),
    };
  });

  return (
    <>
      <Panel title="Live data feed" icon={Braces} right={<span className="chip border-emerald-400/30 bg-emerald-400/10 text-emerald-300">JSON</span>}>
        <div className="num max-h-[280px] overflow-auto rounded-lg border border-white/[0.05] bg-black/30 p-3 text-[11px] leading-relaxed text-slate-300">
          <J v={feed} />
        </div>
      </Panel>

      <Panel title="Events & alerts" icon={BellRing}>
        {events.length === 0 ? (
          <p className="py-4 text-center text-xs text-slate-500">No events detected</p>
        ) : (
          <ul className="space-y-0.5">
            {events.map((e, i) => (
              <li key={i} className="flex items-center gap-3 rounded-lg px-1.5 py-1.5 text-xs hover:bg-white/[0.03]">
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: e.color, boxShadow: `0 0 8px ${e.color}` }} />
                <span className="num w-10 shrink-0 text-slate-500">{e.t === null ? "—" : fmtTime(e.t)}</span>
                <span className="flex-1 truncate text-slate-200">{e.label}</span>
                <span className="num shrink-0 text-slate-400">{e.detail}</span>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel title="Team metrics" icon={Trophy}>
        <PossessionRing analytics={a} />
        <div className="mt-4 overflow-hidden rounded-lg border border-white/[0.05] text-xs">
          <div className="grid grid-cols-[1fr_auto_auto] gap-x-4 border-b border-white/[0.05] bg-white/[0.02] px-3 py-1.5 text-[10px] uppercase tracking-wider text-slate-500">
            <span />
            {teamAgg.map((t) => (
              <span key={t.num} className="num text-right font-semibold" style={{ color: t.color }}>T{t.num}</span>
            ))}
          </div>
          {[
            ["Distance (m)", (t: (typeof teamAgg)[number]) => t.dist.toFixed(0)],
            ["Top speed (km/h)", (t: (typeof teamAgg)[number]) => t.top.toFixed(1)],
            ["Frames w/ ball", (t: (typeof teamAgg)[number]) => String(t.ball)],
          ].map(([label, fn]) => (
            <div key={label as string} className="grid grid-cols-[1fr_auto_auto] gap-x-4 border-b border-white/[0.04] px-3 py-2 last:border-0">
              <span className="text-slate-400">{label as string}</span>
              {teamAgg.map((t) => (
                <span key={t.num} className="num text-right text-slate-100">{(fn as (t: (typeof teamAgg)[number]) => string)(t)}</span>
              ))}
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}
