"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { LayoutDashboard, MonitorPlay, ChevronLeft } from "lucide-react";
import { getAnalyses } from "@/lib/api";

export function Logo({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden>
      <defs>
        <linearGradient id="lg" x1="4" y1="2" x2="36" y2="38" gradientUnits="userSpaceOnUse">
          <stop stopColor="#22d3ee" />
          <stop offset="1" stopColor="#3b82f6" />
        </linearGradient>
      </defs>
      <path d="M20 2 36 11v18L20 38 4 29V11L20 2Z" stroke="url(#lg)" strokeWidth="2" fill="rgba(34,211,238,0.07)" />
      <path d="M20 12 28 16.5v7L20 28l-8-4.5v-7L20 12Z" stroke="url(#lg)" strokeWidth="1.6" />
      <circle cx="20" cy="20" r="2.6" fill="#22d3ee" />
    </svg>
  );
}

type Health = "checking" | "ok" | "down";

function SystemStatus() {
  const [health, setHealth] = useState<Health>("checking");

  useEffect(() => {
    let alive = true;
    const ping = async () => {
      try {
        await getAnalyses();
        if (alive) setHealth("ok");
      } catch {
        if (alive) setHealth("down");
      }
    };
    ping();
    const t = setInterval(ping, 15000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  const map = {
    checking: { text: "Checking…", sub: "Contacting backend", color: "#facc15" },
    ok: { text: "System Status", sub: "All systems operational", color: "#34d399" },
    down: { text: "System Status", sub: "Backend unreachable", color: "#f43f5e" },
  }[health];

  return (
    <div
      className="hidden sm:flex items-center gap-3 rounded-xl px-3.5 py-2"
      style={{ border: `1px solid ${map.color}40`, background: `${map.color}12` }}
    >
      <span className="pulse-dot" style={{ color: map.color }} />
      <div className="leading-tight">
        <p className="text-[10px] uppercase tracking-wider text-slate-400">{map.text}</p>
        <p className="text-xs font-medium" style={{ color: map.color }}>
          {map.sub}
        </p>
      </div>
    </div>
  );
}

export default function AppHeader({
  active,
  center,
}: {
  active: "dashboard" | "match";
  center?: React.ReactNode;
}) {
  const tab = (isActive: boolean) =>
    `relative flex items-center gap-2 px-4 py-2.5 text-sm font-medium transition-colors ${
      isActive ? "text-cyan-300" : "text-slate-400 hover:text-slate-200"
    }`;

  return (
    <header className="sticky top-0 z-50 border-b border-[var(--line)] bg-[#060b16]/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1680px] items-center gap-4 px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-3 shrink-0">
          <Logo />
          <div className="leading-tight">
            <p className="text-[15px] font-bold tracking-[0.08em] text-white">
              PITCH<span className="text-cyan-300">VISION</span> AI
            </p>
            <p className="text-[9px] uppercase tracking-[0.22em] text-slate-500">Football Analysis Platform</p>
          </div>
        </Link>

        {center && <div className="hidden lg:flex min-w-0 flex-1 items-center justify-center">{center}</div>}

        <nav className="ml-auto flex items-center">
          <Link href="/" className={tab(active === "dashboard")}>
            <LayoutDashboard className="h-4 w-4" />
            <span className="hidden sm:inline">Dashboard</span>
            {active === "dashboard" && (
              <span className="absolute inset-x-3 -bottom-[13px] h-[2px] rounded bg-cyan-400 shadow-[0_0_12px_#22d3ee]" />
            )}
          </Link>
          <span className={`${tab(active === "match")} cursor-default`}>
            <MonitorPlay className="h-4 w-4" />
            <span className="hidden sm:inline">Match View</span>
            {active === "match" && (
              <span className="absolute inset-x-3 -bottom-[13px] h-[2px] rounded bg-cyan-400 shadow-[0_0_12px_#22d3ee]" />
            )}
          </span>
        </nav>

        <SystemStatus />
      </div>
    </header>
  );
}

export function BackLink() {
  return (
    <Link href="/" className="btn !px-2.5 !py-1.5" title="Back to dashboard">
      <ChevronLeft className="h-4 w-4" />
      <span className="hidden sm:inline text-xs">Back</span>
    </Link>
  );
}
